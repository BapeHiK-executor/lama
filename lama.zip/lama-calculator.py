import time
import sys

# скорость печати (секунды между символами)
speed = 0.02

def slow_print(text, delay=speed, end="\n"):
    """Постепенная печать текста"""
    for char in str(text):
        sys.stdout.write(char)
        sys.stdout.flush()
        time.sleep(delay)
    sys.stdout.write(end)
    sys.stdout.flush()

def slow_input(prompt=""):
    """Инпут с медленной печатью"""
    slow_print(prompt, end="")
    return input()

def parse_numbers(user_input: str):
    """Парсим числа из строки через пробелы или запятые"""
    parts = user_input.replace(",", " ").split()
    nums = []
    for p in parts:
        try:
            nums.append(int(p))
        except ValueError:
            # ошибки показываем сразу
            print(f"'{p}' не похоже на число, пропускаю.")
    return nums



while True:
    print()
    slow_print("LaMa Calculator")
    time.sleep(0.1)
    slow_print("Класс 6")
    slow_print("\nВыберите режим:")
    slow_print("1 - Проверка на чётность")
    slow_print("2 - Поиск делителей")
    slow_print("ExiT - выйти")
    choice = slow_input(">>> ")

    if choice.lower() == "exit":
        slow_print("Программа завершена.")
        break

    elif choice == "1":  # Проверка на чётность
        while True:
            raw = slow_input("Введите число или список (или ExiT для выхода в меню): ")
            if raw.lower() == "exit":
                break
            numbers = parse_numbers(raw)

            even = [n for n in numbers if n % 2 == 0]
            odd = [n for n in numbers if n % 2 != 0]

            slow_print("\nРезультат:")
            if even:
                slow_print(f"Чётные: {sorted(even)}")
            else:
                slow_print("Чётные: нет")
            if odd:
                slow_print(f"Нечётные: {sorted(odd)}")
            else:
                slow_print("Нечётные: нет")

    elif choice == "2":  # Поиск делителей
        while True:
            raw = slow_input("Введите число или список (или ExiT для выхода в меню): ")
            if raw.lower() == "exit":
                break
            numbers = parse_numbers(raw)
            for num in numbers:
                divisible_numbers = []
                for i in range(2, num):
                    if num % i == 0:
                        divisible_numbers.append(i)
                slow_print(f"\nДля {num}:")
                slow_print(f"Количество делителей: {len(divisible_numbers)}")
                slow_print("Эти числа: " + str(divisible_numbers))

    else:
        slow_print("Такого режима нет! Введите 1, 2 или ExiT.")
